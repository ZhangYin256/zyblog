--
-- PostgreSQL database dump
--

\restrict fGyeN37iLl7z0MPW0EXJI7lDbOFuUHzLvLYRftjM9DKBoSA05pGc42vM242xkzt

-- Dumped from database version 18.4 (Ubuntu 18.4-0ubuntu0.26.04.1)
-- Dumped by pg_dump version 18.4 (Ubuntu 18.4-0ubuntu0.26.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comments (
    id integer NOT NULL,
    post_id integer NOT NULL,
    author_name character varying NOT NULL,
    author_email character varying,
    content text NOT NULL,
    approved boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: comments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.comments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.comments_id_seq OWNED BY public.comments.id;


--
-- Name: images; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.images (
    id integer NOT NULL,
    filename character varying NOT NULL,
    original_name character varying NOT NULL,
    mime_type character varying NOT NULL,
    size integer NOT NULL,
    path character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: images_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.images_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.images_id_seq OWNED BY public.images.id;


--
-- Name: media; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.media (
    id integer NOT NULL,
    filename character varying(255) NOT NULL,
    original_name character varying(255) NOT NULL,
    mime_type character varying(100) NOT NULL,
    size_bytes bigint NOT NULL,
    path character varying(500) NOT NULL,
    uploaded_by integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: media_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.media_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: media_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.media_id_seq OWNED BY public.media.id;


--
-- Name: post_revisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.post_revisions (
    id integer NOT NULL,
    post_id integer NOT NULL,
    title character varying(500),
    content text,
    excerpt text,
    cover_image character varying(500),
    version integer NOT NULL,
    created_by integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: post_revisions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.post_revisions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: post_revisions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.post_revisions_id_seq OWNED BY public.post_revisions.id;


--
-- Name: post_tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.post_tags (
    post_id integer NOT NULL,
    tag_id integer NOT NULL
);


--
-- Name: posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.posts (
    id integer NOT NULL,
    title character varying NOT NULL,
    slug character varying NOT NULL,
    content text NOT NULL,
    excerpt text,
    cover_image character varying,
    published boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    author_id integer,
    current_version integer DEFAULT 1 NOT NULL
);


--
-- Name: posts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.posts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.posts_id_seq OWNED BY public.posts.id;


--
-- Name: pr_comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pr_comments (
    id integer NOT NULL,
    pull_request_id integer NOT NULL,
    fragment_index integer,
    line integer,
    content text NOT NULL,
    user_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: pr_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pr_comments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pr_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pr_comments_id_seq OWNED BY public.pr_comments.id;


--
-- Name: pull_request_comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pull_request_comments (
    id integer NOT NULL,
    pull_request_id integer NOT NULL,
    content text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: pull_request_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pull_request_comments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pull_request_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pull_request_comments_id_seq OWNED BY public.pull_request_comments.id;


--
-- Name: pull_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pull_requests (
    id integer NOT NULL,
    post_id integer NOT NULL,
    user_email character varying NOT NULL,
    content text NOT NULL,
    status character varying DEFAULT 'pending'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    fragments jsonb,
    user_id integer,
    message text
);


--
-- Name: pull_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pull_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pull_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pull_requests_id_seq OWNED BY public.pull_requests.id;


--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.refresh_tokens (
    id integer NOT NULL,
    user_id integer NOT NULL,
    token_hash character varying(255) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.refresh_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.refresh_tokens_id_seq OWNED BY public.refresh_tokens.id;


--
-- Name: seaql_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.seaql_migrations (
    version character varying NOT NULL,
    applied_at bigint NOT NULL
);


--
-- Name: subscribers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscribers (
    id integer NOT NULL,
    email character varying NOT NULL,
    name character varying,
    confirmed boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: subscribers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.subscribers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: subscribers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.subscribers_id_seq OWNED BY public.subscribers.id;


--
-- Name: tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tags (
    id integer NOT NULL,
    name character varying NOT NULL,
    slug character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: tags_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tags_id_seq OWNED BY public.tags.id;


--
-- Name: todo_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.todo_items (
    id integer NOT NULL,
    title character varying NOT NULL,
    description text,
    completed boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    post_id integer DEFAULT 0 NOT NULL
);


--
-- Name: todo_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.todo_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: todo_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.todo_items_id_seq OWNED BY public.todo_items.id;


--
-- Name: todo_subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.todo_subscriptions (
    id integer NOT NULL,
    todo_item_id integer NOT NULL,
    user_id integer,
    email character varying(255),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: todo_subscriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.todo_subscriptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: todo_subscriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.todo_subscriptions_id_seq OWNED BY public.todo_subscriptions.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255),
    name character varying(255) NOT NULL,
    avatar_url character varying(500),
    role character varying(20) DEFAULT 'visitor'::character varying NOT NULL,
    github_id character varying(100),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: comments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comments ALTER COLUMN id SET DEFAULT nextval('public.comments_id_seq'::regclass);


--
-- Name: images id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.images ALTER COLUMN id SET DEFAULT nextval('public.images_id_seq'::regclass);


--
-- Name: media id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.media ALTER COLUMN id SET DEFAULT nextval('public.media_id_seq'::regclass);


--
-- Name: post_revisions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_revisions ALTER COLUMN id SET DEFAULT nextval('public.post_revisions_id_seq'::regclass);


--
-- Name: posts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts ALTER COLUMN id SET DEFAULT nextval('public.posts_id_seq'::regclass);


--
-- Name: pr_comments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pr_comments ALTER COLUMN id SET DEFAULT nextval('public.pr_comments_id_seq'::regclass);


--
-- Name: pull_request_comments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pull_request_comments ALTER COLUMN id SET DEFAULT nextval('public.pull_request_comments_id_seq'::regclass);


--
-- Name: pull_requests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pull_requests ALTER COLUMN id SET DEFAULT nextval('public.pull_requests_id_seq'::regclass);


--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('public.refresh_tokens_id_seq'::regclass);


--
-- Name: subscribers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscribers ALTER COLUMN id SET DEFAULT nextval('public.subscribers_id_seq'::regclass);


--
-- Name: tags id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags ALTER COLUMN id SET DEFAULT nextval('public.tags_id_seq'::regclass);


--
-- Name: todo_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.todo_items ALTER COLUMN id SET DEFAULT nextval('public.todo_items_id_seq'::regclass);


--
-- Name: todo_subscriptions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.todo_subscriptions ALTER COLUMN id SET DEFAULT nextval('public.todo_subscriptions_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.comments (id, post_id, author_name, author_email, content, approved, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: images; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.images (id, filename, original_name, mime_type, size, path, created_at) FROM stdin;
\.


--
-- Data for Name: media; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.media (id, filename, original_name, mime_type, size_bytes, path, uploaded_by, created_at) FROM stdin;
\.


--
-- Data for Name: post_revisions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.post_revisions (id, post_id, title, content, excerpt, cover_image, version, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: post_tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.post_tags (post_id, tag_id) FROM stdin;
\.


--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.posts (id, title, slug, content, excerpt, cover_image, published, created_at, updated_at, author_id, current_version) FROM stdin;
1	QA Test Post	qa-test-post	This is a test post created during QA verification	\N	\N	t	2026-05-27 14:15:28.992746+08	2026-05-27 14:15:28.992746+08	\N	1
3	Integration Test Post	integration-test-post	Testing full workflow	\N	\N	t	2026-05-27 14:15:29.548938+08	2026-05-27 14:15:29.548938+08	\N	1
4	Debug Test Post	debug-test-post	Debug content	\N	\N	t	2026-05-27 14:15:48.690569+08	2026-05-27 14:15:48.690569+08	\N	1
5	QA Final Test	qa-final-test	Full stack verification post	\N	\N	t	2026-05-27 14:18:58.174511+08	2026-05-27 14:18:58.174511+08	\N	1
9	发表	fa-biao	## 标题\n对！	\N	\N	t	2026-05-28 01:09:31.346366+08	2026-05-28 01:09:31.346366+08	\N	1
10	Untitled	untitled	```\r\nSomeone to hold you too close\r\nSomeone to hurt you too deep\r\nSomeone to love you too hard\r\nHappily ever after\r\nSomeone to need you too much\r\nSomeone to read you too well\r\nSomeone to bleed you of all\r\nThe things you don't want to tell—\r\nThat's happily ever after\r\nEver, ever, ever after\r\nIn hell\r\n```\r\n\r\n```\r\n有人他靠你太近\r\n有人他伤你太深\r\n有人他爱你太多\r\n快乐的幸福永久\r\n有人他太需要你\r\n有人他太了解你\r\n有人他让你袒露\r\n那些你不想袒露的秘密——\r\n这就是快乐幸福永久\r\n永远 永远 永远 永远\r\n在地狱里\r\n```\r\n\r\n```\r\nSomebody always there\r\nSitting in the chair\r\nWhere you want to sit\r\nAlways, always\r\nSomebody always there\r\nWanting you to share\r\nJust a little bit\r\nAlways, always\r\nThen see the pretty girls smiling everywhere\r\nFrom the ads and the TV sets\r\nAnd why should you sweat?\r\nWhat do you get?\r\nOne day of grateful for six of regret\r\n```\r\n\r\n```\r\n有个人陪伴你\r\n就在你身旁\r\n抢占你座位\r\n总是，一直\r\n有个人陪伴你\r\n期待你付出\r\n多少都可以\r\n总是，一直\r\n看着路上那些漂亮的姑娘们快乐从心里溢出\r\n从广告里和电视上\r\n而你呢？你的选择，能换来什么？\r\n一丝丝幸福，伴随六倍的伤悲！\r\n```\r\n\r\n```\r\nWith someone to hold you too close\r\nSomeone to hurt you too deep\r\nSomeone to bore you to death\r\nHappily ever after\r\nSomeone you have to know well\r\nSomeone you have to show how\r\nSomeone you have to allow\r\nThe things you'd never allow\r\nThat's happily ever after\r\nEver, ever, ever after\r\n'Til now\r\n```\r\n\r\n```\r\n和那靠你太近的人在一起\r\n和那伤你太深的人在一起\r\n和那让你疲惫的人在一起\r\n快乐的幸福永久\r\n有人你太过熟悉\r\n有人你要去帮助\r\n有人你需要去付出\r\n即使那些你本不愿付出的东西\r\n这就是快乐幸福永久\r\n永远 永远 永远 永远\r\n直到现在\r\n```\r\n\r\n```\r\nSo quick!\r\nGet a little car, take a little drive\r\nMake a little love, see a little flick\r\nDo a little work, take a little walk\r\nWatch a little TV and click!\r\nMake a little love, do a little work\r\nGet a little drunk,\r\nYou've got one little trip, seventy years\r\nSpread it around! Take your pick!\r\nBuy a little here, spend a little there\r\nSmoke a little pot for a little kick\r\nWaste a little time, make a little love\r\nShow a little feeling\r\nBut why should you try?\r\nWhy not, sure, feel a little lonely?\r\nBut fly! Why not fly!\r\n```\r\n\r\n```\r\n那就快一点！\r\n开一辆小车，去一些地方\r\n遇见一个人，开启一段情\r\n做一些付出，在一起徒步\r\n一起开着电视然后——休息！\r\n再做一点爱，做一些付出\r\n喝醉再回家\r\n你得到这一趟人生旅程，七十五年\r\n让它持续下去！就这些了！\r\n这里买一点，那里花一点\r\n烧糊了晚餐，换来一场冲突\r\n浪费些时间，做一点爱\r\n彼此分享些情感\r\n但这些都无法重来\r\n不如，就去拥有一些孤独？\r\n但飞吧！为什么不去飞呢！\r\n```\r\n\r\n```\r\nWith no one to hold you too close\r\nNo one to hurt you too deep\r\nNo one to love you too hard\r\nHappily ever after\r\nNo one you have to know well\r\nNo one you have to show how\r\nNo one you have to allow\r\nThe things you'd never allow\r\nThat's happily ever after\r\nEver, ever, ever after\r\nFor now\r\nEver, ever, ever after\r\nEver, ever, ever ever after\r\nEver, ever, ever after\r\n```\r\n\r\n```\r\n没有谁能靠你太近\r\n没有谁能伤你太深\r\n没有谁能爱你太多\r\n快乐的幸福永久\r\n不用去和谁互相熟悉\r\n不用去为谁提供帮助\r\n不用去和谁共同分担\r\n那些你本不愿付出的事情\r\n这就是快乐幸福永久\r\n永远 永远 永远 永远\r\n活在现在……\r\n永远 永远 永远 永远\r\n永远 永远 永远 永远 永远\r\n永远 永远 永远 永远\r\n```	\N	\N	t	2026-05-28 01:22:20.789957+08	2026-05-28 01:22:20.789957+08	\N	1
12	鸣谢	ming-xie	引子：一些火车积分要过期了，不去哪玩玩白白浪费\r\n前置条件：这周六难得闲暇\r\n# 鸣谢\r\n面包老师和众互联网大侠的旅行攻略，预先确定了一些游玩地点和吃食\r\n高德地图、十六番旅行，使我不至丢失\r\n以及本地人，以及时代\r\n# 需求\r\n基于前述信息来源与个人见闻，此行的预期：\r\n- 阿炳故居\r\n- 无锡美术馆\r\n- 惠山古镇-“天下第二泉”&特色豆腐花\r\n- 南长街\r\n- 诸多吃食（面、小笼包等）\r\n如时间充裕，梅园可作为目标之一\r\n# 初步规划\r\n- 无锡站->一号线->三阳广场\r\n\t参观阿炳故居以及无锡美术馆\r\n\t周边其他可游览展馆不少\r\n\t期间寻找中意吃食\r\n- 至惠山古镇\r\n\t***此程路径规划应当在一小时的车程中完成***\r\n\t惠山豆腐花\r\n- 至南长街\r\n\t此程地铁可达，如有更好的地上交通则选择之\r\n# 细化\r\n## 至南京南的更优解法\r\n6:56从宿舍出发，使用7ma送的最后一次电单车券，7:04至东北门\r\n参照小红书攻略，从4号口出站[^1]\r\n7:31从地铁站出站，通过南进站口，7:37进入车站（若赶时间，速度还有提升空间，但不多）\r\n此入口靠近序号较大的站台\r\n## 路径规划\r\n三阳广场附近至惠山古镇可乘坐15、75路，从崇山寺至惠山公交站\r\n惠山古镇至南长街，可乘坐15路，从龙光路（古华山路）至跨塘桥（南长街）公交站\r\n南长街至无锡站需乘地铁一号线，至少留出40分钟\r\n## 吃食规划\r\n规划什么，看见啥吃啥\r\n# 实行\r\n## 崇安寺景区区块\r\n### 丰收糕团店\r\n本想直奔阿炳故居，但到达已经十点有余，饿\r\n离故居不远，内有各色糕团、粉丝、面食以及糖桂花制品\r\n一碗桂花糖芋头下肚——————不饿了（\r\n回过头才发现真香真甜且别有风味\r\n### 阿炳故居\r\n虽说饥饿值没有回满，但也足够不掉血地再浪几个小时\r\n除开绝大部分已经听烂了讲烂了的东西，有一些额外收获：\r\n钢丝录音机、刷新了对阿炳多才多艺的认知\r\n并且杵在那里听了二十分钟原声带\r\n有个影响体验的是机器静置一段时间后会关闭当前播放的页面回到主界面——但此时曲子还没有放完\r\n感觉现地还原做的不是很好——虽说场景是比较寒酸，但放着的琵琶二胡总不能缺琴头吧\r\n### 无锡图书馆旧址\r\n没什么东西，但建筑比较有意思（年代感？）\r\n### 锡剧博物馆\r\n时间仓促、瞟了两眼走了\r\n胡琴居然还有主胡副胡之分\r\n见到一张金唱片\r\n有一些传统锡剧演出 *什么时候再有时间，想来看看*\r\n### 无锡市书画院（美术馆）\r\n有一些具象和抽象艺术，但鉴于本人的平面艺术欣赏水平极差，略去不提\r\n## 惠山古镇景区\r\n公交车有无障碍区域，好评\r\n景区平地区域人好多好多，但愈往上人愈少~~，且所见愈奇~~\r\n### 又饿了，进入逛吃逛吃模式\r\n**蟹粉包\\*1**，味道不错\r\n见到一个疑似自控原理的水钟（漏刻）\r\n见到馓子和矮子馅饼~~，回家了吗这是~~\r\n**肉松咸蛋黄青团\\*1**，馅子味道拥有过于浓重的刻板印象以至于没有青团的香了\r\n**桂花糕一盒12枚**，淡淡的香，黏牙\r\n没吃完，带回宿舍晚上吃，口感差了好几个档次。还是刚出炉的好\r\n### 行为艺术家\r\n讲真我挺讨厌流行曲目把人声直接移植到二胡上的~~，你的创新点在哪里你的独有优势又在哪里~~\r\n不过这家伙旁边伴奏的笛儿和电吹管还不错\r\n不过既然自我定位是【行为艺术】，也不必苛求什么了\r\n### 华彦钧之墓\r\n华彦钧，阿炳之本名\r\n十块钱上山门票，学生半价\r\n刚上一点就有块平地，旁边是个小园子\r\n墙里面是雕像和碑，外面是碑的碑（简介、保护单位之类）\r\n坊间流传阿炳的背没那么驼\r\n### 上山\r\n因为山就在那里\r\n### 下山\r\n坐缆车，爬不动了~~体力杂鱼~~\r\n缆车上风景不错，姑且能遍览无锡全貌\r\n中间有段视野不好，刷了刷旅行攻略，推荐上山爬而下山坐缆车~~，找不到链接了疑似学术不端~~\r\n嗯，确实\r\n### 回\r\n下了缆车从另一边回到景区入口\r\n跨了个大运河\r\n## 长南街\r\n到了这里，彰隐才想起来面包老师推荐了豆腐花和面来着\r\n### 神秘五元店\r\n我是真没想到会有这种地方，而且会在这种地方爆金币\r\n竖直瓶装蜂蜜柚子，如此便携\r\n奇怪功能的小杯子\r\n### 继续吃\r\n没见过的，**海棠糕\\*1**，吃\r\n**豆腐花和油烧饼**，前者咸甜兼具，后者第一感觉是“这玩意居然也是甜的”\r\n### 意外之喜\r\n路过了春晚分会场舞台，比想象中小\r\n旁边是运河文化博物馆，居然正在办拿破仑家具展\r\n这法国人审美还真是有点水平的\r\n的确是很有意思、很新奇（指自己见识短没见过）的切入角度\r\n### 又回\r\n从河的另一边回，路过了三家酒酿，试喝了三杯\r\n其二是桂花酒酿，其一其三是普通的\r\n呃，像是风味醪糟——就很醪糟，但是多点不一样的风味\r\n现在又有点小饿，但是面是绝对吃不下了\r\n浅炫了四个**无锡汤包**\r\n好了，坐地铁，回\r\n\r\n# 参考文献\r\n[^1]:南京南站5min进站路线 小红书	\N	\N	t	2026-05-29 00:01:04.769434+08	2026-05-29 00:01:04.769434+08	\N	1
13	无题	wu-ti	## title\n```plaintext\naaaa aaa aaa' aa'\n```	\N	\N	t	2026-05-29 00:09:41.888497+08	2026-05-29 00:09:41.888497+08	\N	1
\.


--
-- Data for Name: pr_comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pr_comments (id, pull_request_id, fragment_index, line, content, user_id, created_at) FROM stdin;
\.


--
-- Data for Name: pull_request_comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pull_request_comments (id, pull_request_id, content, created_at) FROM stdin;
\.


--
-- Data for Name: pull_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pull_requests (id, post_id, user_email, content, status, created_at, fragments, user_id, message) FROM stdin;
1	5	3615868316@qq.com	增添内容	merged	2026-05-28 01:01:51.255291+08	\N	\N	\N
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.refresh_tokens (id, user_id, token_hash, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: seaql_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.seaql_migrations (version, applied_at) FROM stdin;
m20240101_000001_create_posts_table	1779855236
m20240101_000002_create_todo_items_table	1779855236
m20240101_000003_create_subscribers_table	1779855236
m20240101_000004_create_images_table	1779855236
m20240101_000005_add_post_id_to_todo_items	1779855236
m20240101_000006_create_pull_requests_table	1779855236
m20240101_000007_create_pull_request_comments_table	1779855236
m20240101_000008_create_tags_table	1779945393
m20240101_000009_create_post_tags_table	1779945393
m20240101_000010_create_comments_table	1779945393
m20240101_000011_create_users_table	1779963463
m20240101_000012_create_refresh_tokens_table	1779963463
m20240101_000013_add_author_id_to_posts	1779981581
m20240101_000014_create_post_revisions_table	1779981581
m20240101_000015_add_version_to_posts	1779981581
m20240101_000016_redesign_pull_requests_table	1779981581
m20240101_000017_create_media_table	1779981581
m20240101_000018_create_pr_comments_table	1779981581
m20240101_000019_create_todo_subscriptions_table	1779981581
\.


--
-- Data for Name: subscribers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscribers (id, email, name, confirmed, created_at) FROM stdin;
1	qa-test@example.com	\N	f	2026-05-27 14:15:29.075525+08
2	invalid-email	\N	f	2026-05-27 14:15:29.501353+08
3	qatest@example.com	\N	f	2026-05-27 14:18:58.275096+08
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tags (id, name, slug, created_at) FROM stdin;
\.


--
-- Data for Name: todo_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.todo_items (id, title, description, completed, created_at, updated_at, post_id) FROM stdin;
\.


--
-- Data for Name: todo_subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.todo_subscriptions (id, todo_item_id, user_id, email, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, password_hash, name, avatar_url, role, github_id, created_at, updated_at) FROM stdin;
1	admin@zyblog.local	\N	Admin	\N	admin	\N	2026-05-28 23:12:25.240032+08	2026-05-28 23:12:25.240032+08
\.


--
-- Name: comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.comments_id_seq', 1, false);


--
-- Name: images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.images_id_seq', 1, false);


--
-- Name: media_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.media_id_seq', 1, false);


--
-- Name: post_revisions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.post_revisions_id_seq', 1, false);


--
-- Name: posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.posts_id_seq', 13, true);


--
-- Name: pr_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pr_comments_id_seq', 1, false);


--
-- Name: pull_request_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pull_request_comments_id_seq', 1, false);


--
-- Name: pull_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pull_requests_id_seq', 1, true);


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.refresh_tokens_id_seq', 1, false);


--
-- Name: subscribers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.subscribers_id_seq', 3, true);


--
-- Name: tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tags_id_seq', 1, false);


--
-- Name: todo_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.todo_items_id_seq', 1, false);


--
-- Name: todo_subscriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.todo_subscriptions_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (id);


--
-- Name: images images_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.images
    ADD CONSTRAINT images_pkey PRIMARY KEY (id);


--
-- Name: media media_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT media_pkey PRIMARY KEY (id);


--
-- Name: post_revisions post_revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_revisions
    ADD CONSTRAINT post_revisions_pkey PRIMARY KEY (id);


--
-- Name: post_tags post_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_tags
    ADD CONSTRAINT post_tags_pkey PRIMARY KEY (post_id, tag_id);


--
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (id);


--
-- Name: posts posts_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_slug_key UNIQUE (slug);


--
-- Name: pr_comments pr_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pr_comments
    ADD CONSTRAINT pr_comments_pkey PRIMARY KEY (id);


--
-- Name: pull_request_comments pull_request_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pull_request_comments
    ADD CONSTRAINT pull_request_comments_pkey PRIMARY KEY (id);


--
-- Name: pull_requests pull_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pull_requests
    ADD CONSTRAINT pull_requests_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: seaql_migrations seaql_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seaql_migrations
    ADD CONSTRAINT seaql_migrations_pkey PRIMARY KEY (version);


--
-- Name: subscribers subscribers_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscribers
    ADD CONSTRAINT subscribers_email_key UNIQUE (email);


--
-- Name: subscribers subscribers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscribers
    ADD CONSTRAINT subscribers_pkey PRIMARY KEY (id);


--
-- Name: tags tags_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_name_key UNIQUE (name);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: tags tags_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_slug_key UNIQUE (slug);


--
-- Name: todo_items todo_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.todo_items
    ADD CONSTRAINT todo_items_pkey PRIMARY KEY (id);


--
-- Name: todo_subscriptions todo_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.todo_subscriptions
    ADD CONSTRAINT todo_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_github_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_github_id_key UNIQUE (github_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_comments_post_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_comments_post_id ON public.comments USING btree (post_id);


--
-- Name: idx_media_uploaded_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_media_uploaded_by ON public.media USING btree (uploaded_by);


--
-- Name: idx_post_revisions_post_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_post_revisions_post_id ON public.post_revisions USING btree (post_id);


--
-- Name: idx_post_revisions_version; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_post_revisions_version ON public.post_revisions USING btree (post_id, version);


--
-- Name: idx_post_tags_tag_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_post_tags_tag_id ON public.post_tags USING btree (tag_id);


--
-- Name: idx_pr_comments_pull_request_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pr_comments_pull_request_id ON public.pr_comments USING btree (pull_request_id);


--
-- Name: idx_pull_request_comments_pull_request_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pull_request_comments_pull_request_id ON public.pull_request_comments USING btree (pull_request_id);


--
-- Name: idx_pull_requests_post_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pull_requests_post_id ON public.pull_requests USING btree (post_id);


--
-- Name: idx_pull_requests_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pull_requests_status ON public.pull_requests USING btree (status);


--
-- Name: idx_refresh_tokens_token_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_refresh_tokens_token_hash ON public.refresh_tokens USING btree (token_hash);


--
-- Name: idx_refresh_tokens_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_refresh_tokens_user_id ON public.refresh_tokens USING btree (user_id);


--
-- Name: idx_todo_items_post_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_todo_items_post_id ON public.todo_items USING btree (post_id);


--
-- Name: idx_todo_subscriptions_todo_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_todo_subscriptions_todo_item_id ON public.todo_subscriptions USING btree (todo_item_id);


--
-- Name: uq_todo_subscriptions_todo_item_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_todo_subscriptions_todo_item_email ON public.todo_subscriptions USING btree (todo_item_id, email);


--
-- Name: uq_todo_subscriptions_todo_item_user; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_todo_subscriptions_todo_item_user ON public.todo_subscriptions USING btree (todo_item_id, user_id);


--
-- Name: comments fk_comments_post_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT fk_comments_post_id FOREIGN KEY (post_id) REFERENCES public.posts(id) ON DELETE CASCADE;


--
-- Name: media fk_media_uploaded_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT fk_media_uploaded_by FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- Name: post_revisions fk_post_revisions_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_revisions
    ADD CONSTRAINT fk_post_revisions_created_by FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: post_revisions fk_post_revisions_post_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_revisions
    ADD CONSTRAINT fk_post_revisions_post_id FOREIGN KEY (post_id) REFERENCES public.posts(id) ON DELETE CASCADE;


--
-- Name: post_tags fk_post_tags_post_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_tags
    ADD CONSTRAINT fk_post_tags_post_id FOREIGN KEY (post_id) REFERENCES public.posts(id) ON DELETE CASCADE;


--
-- Name: post_tags fk_post_tags_tag_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_tags
    ADD CONSTRAINT fk_post_tags_tag_id FOREIGN KEY (tag_id) REFERENCES public.tags(id) ON DELETE CASCADE;


--
-- Name: posts fk_posts_author_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT fk_posts_author_id FOREIGN KEY (author_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: pr_comments fk_pr_comments_pull_request_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pr_comments
    ADD CONSTRAINT fk_pr_comments_pull_request_id FOREIGN KEY (pull_request_id) REFERENCES public.pull_requests(id) ON DELETE CASCADE;


--
-- Name: pr_comments fk_pr_comments_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pr_comments
    ADD CONSTRAINT fk_pr_comments_user_id FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: pull_request_comments fk_pull_request_comments_pull_request_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pull_request_comments
    ADD CONSTRAINT fk_pull_request_comments_pull_request_id FOREIGN KEY (pull_request_id) REFERENCES public.pull_requests(id) ON DELETE CASCADE;


--
-- Name: pull_requests fk_pull_requests_post_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pull_requests
    ADD CONSTRAINT fk_pull_requests_post_id FOREIGN KEY (post_id) REFERENCES public.posts(id) ON DELETE CASCADE;


--
-- Name: pull_requests fk_pull_requests_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pull_requests
    ADD CONSTRAINT fk_pull_requests_user_id FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: refresh_tokens fk_refresh_tokens_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT fk_refresh_tokens_user_id FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: todo_subscriptions fk_todo_subscriptions_todo_item_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.todo_subscriptions
    ADD CONSTRAINT fk_todo_subscriptions_todo_item_id FOREIGN KEY (todo_item_id) REFERENCES public.todo_items(id) ON DELETE CASCADE;


--
-- Name: todo_subscriptions fk_todo_subscriptions_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.todo_subscriptions
    ADD CONSTRAINT fk_todo_subscriptions_user_id FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict fGyeN37iLl7z0MPW0EXJI7lDbOFuUHzLvLYRftjM9DKBoSA05pGc42vM242xkzt

