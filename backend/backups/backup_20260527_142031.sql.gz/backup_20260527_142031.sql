--
-- PostgreSQL database dump
--

\restrict 3Ro9Yog45koVPhhyMnb30b5kN8GnHbeUmbOHtOX1tInDXbqefoWqhTHh5ffUB0w

-- Dumped from database version 18.4 (Ubuntu 18.4-0ubuntu0.26.04.1)
-- Dumped by pg_dump version 18.4 (Ubuntu 18.4-0ubuntu0.26.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: images; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.images (
    id integer NOT NULL,
    filename character varying NOT NULL,
    original_name character varying NOT NULL,
    mime_type character varying NOT NULL,
    size integer NOT NULL,
    path character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: images_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.images_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.images_id_seq OWNED BY public.images.id;


--
-- Name: posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.posts (
    id integer NOT NULL,
    title character varying NOT NULL,
    slug character varying NOT NULL,
    content text NOT NULL,
    excerpt text,
    cover_image character varying,
    published boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: posts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.posts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.posts_id_seq OWNED BY public.posts.id;


--
-- Name: pull_request_comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pull_request_comments (
    id integer NOT NULL,
    pull_request_id integer NOT NULL,
    content text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: pull_request_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pull_request_comments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pull_request_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pull_request_comments_id_seq OWNED BY public.pull_request_comments.id;


--
-- Name: pull_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pull_requests (
    id integer NOT NULL,
    post_id integer NOT NULL,
    user_email character varying NOT NULL,
    content text NOT NULL,
    status character varying DEFAULT 'pending'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: pull_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pull_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pull_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pull_requests_id_seq OWNED BY public.pull_requests.id;


--
-- Name: seaql_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.seaql_migrations (
    version character varying NOT NULL,
    applied_at bigint NOT NULL
);


--
-- Name: subscribers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscribers (
    id integer NOT NULL,
    email character varying NOT NULL,
    name character varying,
    confirmed boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: subscribers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.subscribers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: subscribers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.subscribers_id_seq OWNED BY public.subscribers.id;


--
-- Name: todo_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.todo_items (
    id integer NOT NULL,
    title character varying NOT NULL,
    description text,
    completed boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    post_id integer DEFAULT 0 NOT NULL
);


--
-- Name: todo_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.todo_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: todo_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.todo_items_id_seq OWNED BY public.todo_items.id;


--
-- Name: images id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.images ALTER COLUMN id SET DEFAULT nextval('public.images_id_seq'::regclass);


--
-- Name: posts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts ALTER COLUMN id SET DEFAULT nextval('public.posts_id_seq'::regclass);


--
-- Name: pull_request_comments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pull_request_comments ALTER COLUMN id SET DEFAULT nextval('public.pull_request_comments_id_seq'::regclass);


--
-- Name: pull_requests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pull_requests ALTER COLUMN id SET DEFAULT nextval('public.pull_requests_id_seq'::regclass);


--
-- Name: subscribers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscribers ALTER COLUMN id SET DEFAULT nextval('public.subscribers_id_seq'::regclass);


--
-- Name: todo_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.todo_items ALTER COLUMN id SET DEFAULT nextval('public.todo_items_id_seq'::regclass);


--
-- Data for Name: images; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.images (id, filename, original_name, mime_type, size, path, created_at) FROM stdin;
\.


--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.posts (id, title, slug, content, excerpt, cover_image, published, created_at, updated_at) FROM stdin;
1	QA Test Post	qa-test-post	This is a test post created during QA verification	\N	\N	t	2026-05-27 14:15:28.992746+08	2026-05-27 14:15:28.992746+08
2	Post with empty content	post-with-empty-content		\N	\N	f	2026-05-27 14:15:29.475221+08	2026-05-27 14:15:29.475221+08
3	Integration Test Post	integration-test-post	Testing full workflow	\N	\N	t	2026-05-27 14:15:29.548938+08	2026-05-27 14:15:29.548938+08
4	Debug Test Post	debug-test-post	Debug content	\N	\N	t	2026-05-27 14:15:48.690569+08	2026-05-27 14:15:48.690569+08
5	QA Final Test	qa-final-test	Full stack verification post	\N	\N	t	2026-05-27 14:18:58.174511+08	2026-05-27 14:18:58.174511+08
6	Route Test	route-test	test	\N	\N	f	2026-05-27 14:19:36.581335+08	2026-05-27 14:19:36.581335+08
7	Untitled	untitled	引子：一些火车积分要过期了，不去哪玩玩白白浪费\r\n前置条件：这周六难得闲暇\r\n# 鸣谢\r\n面包老师和众互联网大侠的旅行攻略，预先确定了一些游玩地点和吃食\r\n高德地图、十六番旅行，使我不至丢失\r\n以及本地人，以及时代\r\n# 需求\r\n基于前述信息来源与个人见闻，此行的预期：\r\n- 阿炳故居\r\n- 无锡美术馆\r\n- 惠山古镇-“天下第二泉”&特色豆腐花\r\n- 南长街\r\n- 诸多吃食（面、小笼包等）\r\n如时间充裕，梅园可作为目标之一\r\n# 初步规划\r\n- 无锡站->一号线->三阳广场\r\n\t参观阿炳故居以及无锡美术馆\r\n\t周边其他可游览展馆不少\r\n\t期间寻找中意吃食\r\n- 至惠山古镇\r\n\t***此程路径规划应当在一小时的车程中完成***\r\n\t惠山豆腐花\r\n- 至南长街\r\n\t此程地铁可达，如有更好的地上交通则选择之\r\n# 细化\r\n## 至南京南的更优解法\r\n6:56从宿舍出发，使用7ma送的最后一次电单车券，7:04至东北门\r\n参照小红书攻略，从4号口出站[^1]\r\n7:31从地铁站出站，通过南进站口，7:37进入车站（若赶时间，速度还有提升空间，但不多）\r\n此入口靠近序号较大的站台\r\n## 路径规划\r\n三阳广场附近至惠山古镇可乘坐15、75路，从崇山寺至惠山公交站\r\n惠山古镇至南长街，可乘坐15路，从龙光路（古华山路）至跨塘桥（南长街）公交站\r\n南长街至无锡站需乘地铁一号线，至少留出40分钟\r\n## 吃食规划\r\n规划什么，看见啥吃啥\r\n# 实行\r\n## 崇安寺景区区块\r\n### 丰收糕团店\r\n本想直奔阿炳故居，但到达已经十点有余，饿\r\n离故居不远，内有各色糕团、粉丝、面食以及糖桂花制品\r\n一碗桂花糖芋头下肚——————不饿了（\r\n回过头才发现真香真甜且别有风味\r\n### 阿炳故居\r\n虽说饥饿值没有回满，但也足够不掉血地再浪几个小时\r\n除开绝大部分已经听烂了讲烂了的东西，有一些额外收获：\r\n钢丝录音机、刷新了对阿炳多才多艺的认知\r\n并且杵在那里听了二十分钟原声带\r\n有个影响体验的是机器静置一段时间后会关闭当前播放的页面回到主界面——但此时曲子还没有放完\r\n感觉现地还原做的不是很好——虽说场景是比较寒酸，但放着的琵琶二胡总不能缺琴头吧\r\n### 无锡图书馆旧址\r\n没什么东西，但建筑比较有意思（年代感？）\r\n### 锡剧博物馆\r\n时间仓促、瞟了两眼走了\r\n胡琴居然还有主胡副胡之分\r\n见到一张金唱片\r\n有一些传统锡剧演出 *什么时候再有时间，想来看看*\r\n### 无锡市书画院（美术馆）\r\n有一些具象和抽象艺术，但鉴于本人的平面艺术欣赏水平极差，略去不提\r\n## 惠山古镇景区\r\n公交车有无障碍区域，好评\r\n景区平地区域人好多好多，但愈往上人愈少~~，且所见愈奇~~\r\n### 又饿了，进入逛吃逛吃模式\r\n**蟹粉包\\*1**，味道不错\r\n见到一个疑似自控原理的水钟（漏刻）\r\n见到馓子和矮子馅饼~~，回家了吗这是~~\r\n**肉松咸蛋黄青团\\*1**，馅子味道拥有过于浓重的刻板印象以至于没有青团的香了\r\n**桂花糕一盒12枚**，淡淡的香，黏牙\r\n没吃完，带回宿舍晚上吃，口感差了好几个档次。还是刚出炉的好\r\n### 行为艺术家\r\n讲真我挺讨厌流行曲目把人声直接移植到二胡上的~~，你的创新点在哪里你的独有优势又在哪里~~\r\n不过这家伙旁边伴奏的笛儿和电吹管还不错\r\n不过既然自我定位是【行为艺术】，也不必苛求什么了\r\n### 华彦钧之墓\r\n华彦钧，阿炳之本名\r\n十块钱上山门票，学生半价\r\n刚上一点就有块平地，旁边是个小园子\r\n墙里面是雕像和碑，外面是碑的碑（简介、保护单位之类）\r\n坊间流传阿炳的背没那么驼\r\n### 上山\r\n因为山就在那里\r\n### 下山\r\n坐缆车，爬不动了~~体力杂鱼~~\r\n缆车上风景不错，姑且能遍览无锡全貌\r\n中间有段视野不好，刷了刷旅行攻略，推荐上山爬而下山坐缆车~~，找不到链接了疑似学术不端~~\r\n嗯，确实\r\n### 回\r\n下了缆车从另一边回到景区入口\r\n跨了个大运河\r\n## 长南街\r\n到了这里，彰隐才想起来面包老师推荐了豆腐花和面来着\r\n### 神秘五元店\r\n我是真没想到会有这种地方，而且会在这种地方爆金币\r\n竖直瓶装蜂蜜柚子，如此便携\r\n奇怪功能的小杯子\r\n### 继续吃\r\n没见过的，**海棠糕\\*1**，吃\r\n**豆腐花和油烧饼**，前者咸甜兼具，后者第一感觉是“这玩意居然也是甜的”\r\n### 意外之喜\r\n路过了春晚分会场舞台，比想象中小\r\n旁边是运河文化博物馆，居然正在办拿破仑家具展\r\n这法国人审美还真是有点水平的\r\n的确是很有意思、很新奇（指自己见识短没见过）的切入角度\r\n### 又回\r\n从河的另一边回，路过了三家酒酿，试喝了三杯\r\n其二是桂花酒酿，其一其三是普通的\r\n呃，像是风味醪糟——就很醪糟，但是多点不一样的风味\r\n现在又有点小饿，但是面是绝对吃不下了\r\n浅炫了四个**无锡汤包**\r\n好了，坐地铁，回\r\n\r\n# 参考文献\r\n[^1]:南京南站5min进站路线 小红书	\N	\N	f	2026-05-27 21:45:13.688231+08	2026-05-27 21:45:13.688231+08
\.


--
-- Data for Name: pull_request_comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pull_request_comments (id, pull_request_id, content, created_at) FROM stdin;
\.


--
-- Data for Name: pull_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pull_requests (id, post_id, user_email, content, status, created_at) FROM stdin;
\.


--
-- Data for Name: seaql_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.seaql_migrations (version, applied_at) FROM stdin;
m20240101_000001_create_posts_table	1779855236
m20240101_000002_create_todo_items_table	1779855236
m20240101_000003_create_subscribers_table	1779855236
m20240101_000004_create_images_table	1779855236
m20240101_000005_add_post_id_to_todo_items	1779855236
m20240101_000006_create_pull_requests_table	1779855236
m20240101_000007_create_pull_request_comments_table	1779855236
\.


--
-- Data for Name: subscribers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscribers (id, email, name, confirmed, created_at) FROM stdin;
1	qa-test@example.com	\N	f	2026-05-27 14:15:29.075525+08
2	invalid-email	\N	f	2026-05-27 14:15:29.501353+08
3	qatest@example.com	\N	f	2026-05-27 14:18:58.275096+08
\.


--
-- Data for Name: todo_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.todo_items (id, title, description, completed, created_at, updated_at, post_id) FROM stdin;
\.


--
-- Name: images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.images_id_seq', 1, false);


--
-- Name: posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.posts_id_seq', 7, true);


--
-- Name: pull_request_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pull_request_comments_id_seq', 1, false);


--
-- Name: pull_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pull_requests_id_seq', 1, false);


--
-- Name: subscribers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.subscribers_id_seq', 3, true);


--
-- Name: todo_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.todo_items_id_seq', 1, false);


--
-- Name: images images_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.images
    ADD CONSTRAINT images_pkey PRIMARY KEY (id);


--
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (id);


--
-- Name: posts posts_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_slug_key UNIQUE (slug);


--
-- Name: pull_request_comments pull_request_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pull_request_comments
    ADD CONSTRAINT pull_request_comments_pkey PRIMARY KEY (id);


--
-- Name: pull_requests pull_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pull_requests
    ADD CONSTRAINT pull_requests_pkey PRIMARY KEY (id);


--
-- Name: seaql_migrations seaql_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seaql_migrations
    ADD CONSTRAINT seaql_migrations_pkey PRIMARY KEY (version);


--
-- Name: subscribers subscribers_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscribers
    ADD CONSTRAINT subscribers_email_key UNIQUE (email);


--
-- Name: subscribers subscribers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscribers
    ADD CONSTRAINT subscribers_pkey PRIMARY KEY (id);


--
-- Name: todo_items todo_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.todo_items
    ADD CONSTRAINT todo_items_pkey PRIMARY KEY (id);


--
-- Name: idx_pull_request_comments_pull_request_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pull_request_comments_pull_request_id ON public.pull_request_comments USING btree (pull_request_id);


--
-- Name: idx_pull_requests_post_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pull_requests_post_id ON public.pull_requests USING btree (post_id);


--
-- Name: idx_pull_requests_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pull_requests_status ON public.pull_requests USING btree (status);


--
-- Name: idx_todo_items_post_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_todo_items_post_id ON public.todo_items USING btree (post_id);


--
-- Name: pull_request_comments fk_pull_request_comments_pull_request_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pull_request_comments
    ADD CONSTRAINT fk_pull_request_comments_pull_request_id FOREIGN KEY (pull_request_id) REFERENCES public.pull_requests(id) ON DELETE CASCADE;


--
-- Name: pull_requests fk_pull_requests_post_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pull_requests
    ADD CONSTRAINT fk_pull_requests_post_id FOREIGN KEY (post_id) REFERENCES public.posts(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 3Ro9Yog45koVPhhyMnb30b5kN8GnHbeUmbOHtOX1tInDXbqefoWqhTHh5ffUB0w

